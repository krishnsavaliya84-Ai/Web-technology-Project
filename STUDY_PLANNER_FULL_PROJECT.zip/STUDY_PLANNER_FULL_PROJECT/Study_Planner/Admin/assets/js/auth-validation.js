/* Study Planner Pro — student / admin demo authentication validation.
   Front-end coursework only. LocalStorage is NOT secure authentication. */
(() => {
  'use strict';
  const DATA_KEY = 'studyplanner_data_v1';
  const SESSION_KEY = 'studyplanner_session_v1';
  const FAIL_KEY = 'studyplanner_auth_fail_v1';
  const $ = selector => document.querySelector(selector);
  const page = document.body?.dataset.page;
  if (!['login', 'admin-login', 'register'].includes(page)) return;

  function getData() {
    try { return JSON.parse(localStorage.getItem(DATA_KEY)) || null; }
    catch (_) { return null; }
  }
  function validEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value) && value.length <= 120;
  }
  const normalizeEmail = s => String(s || '').trim().toLowerCase();
  function errorFor(id, message) {
    const input = $('#' + id);
    const feedback = $('#' + id + '-error');
    if (!input) return;
    input.classList.toggle('is-invalid', Boolean(message));
    input.setAttribute('aria-invalid', String(Boolean(message)));
    if (feedback) {
      feedback.textContent = message || '';
      feedback.classList.toggle('d-block', Boolean(message));
    }
  }
  function banner(which, message) {
    const el = $('#' + which + '-form-error');
    if (el) {
      el.textContent = message || '';
      el.classList.toggle('d-none', !message);
    }
  }
  const loginRole = page === 'admin-login' ? 'admin' : 'student';
  const nameValid = value => /^[\p{L}][\p{L} .'-]*$/u.test(value);
  const passRules = {
    length: p => p.length >= 8 && p.length <= 64,
    upper: p => /[A-Z]/.test(p),
    lower: p => /[a-z]/.test(p),
    number: p => /\d/.test(p),
    symbol: p => /[^A-Za-z\d\s]/.test(p),
    spaces: p => !/\s/.test(p)
  };
  const strongPassword = p => Object.values(passRules).every(check => check(p));

  function passwordHint() {
    const input = $('#reg-password');
    if (!input) return;
    const p = input.value;
    const checks = Object.entries(passRules).map(([key, fn]) => [key, fn(p)]);
    for (const [key, ok] of checks) {
      const row = $('[data-rule="' + key + '"]');
      if (row) row.classList.toggle('met', Boolean(p) && ok);
    }
    const strength = $('#strength-bar');
    const caption = $('#strength-text');
    const matched = checks.filter(x => x[1]).length;
    const score = p.length ? (matched <= 2 ? 1 : matched <= 4 ? 2 : matched === 5 ? 3 : 4) : 0;
    if (strength) {
      strength.style.width = (score * 25) + '%';
      strength.dataset.strength = String(score);
    }
    if (caption) caption.textContent = !p ? 'A strong password needs all six requirements below.' :
      score === 4 ? 'Strong password — all requirements met.' :
      score === 3 ? 'Almost there — complete the remaining requirement.' :
      score === 2 ? 'Moderate password — add more variety.' : 'Weak password — follow the requirements below.';
  }

  function checkLogin(id) {
    const input = $('#' + id);
    const val = input?.value || '';
    let message = '';
    if (id === 'login-email') {
      const v = normalizeEmail(val);
      if (!v) message = 'Email address is required.';
      else if (!validEmail(v)) message = 'Enter a valid email address (example@domain.com).';
    } else if (id === 'login-password') {
      // Fig 1.2 — Password Length: minimum 8 and maximum 64 characters.
      // Fig 1.4 — Password Pattern: uppercase, lowercase, digit, symbol, no spaces.
      if (!val || val.trim().length === 0) message = 'Password is required.';
      else if (val.length < 8 || val.length > 64) message = 'Password must be 8–64 characters long.';
      else if (!strongPassword(val)) message = 'Password must include uppercase, lowercase, a number, a special character and no spaces.';
    } else if (id === 'login-phone') {
      // Fig 1.5 — Indian phone number pattern (optional login practice field).
      // Blank is accepted: a mobile number is not an authentication credential.
      if (val && !/^[6-9][0-9]{9}$/.test(val.trim())) {
        message = 'Enter a valid 10-digit Indian mobile number starting with 6–9.';
      }
    }
    errorFor(id, message);
    return !message;
  }

  function checkRegister(id) {
    const input = $('#' + id);
    const raw = input?.value || '';
    const value = raw.trim();
    let message = '';
    switch (id) {
      case 'reg-name':
        if (!value) message = 'Full name is required.';
        else if (value.length < 2 || value.length > 70) message = 'Name must be 2–70 characters.';
        else if (!nameValid(value)) message = 'Use letters, spaces, periods, apostrophes or hyphens.';
        break;
      case 'reg-email':
        if (!value) message = 'Email address is required.';
        else if (!validEmail(normalizeEmail(raw))) message = 'Enter a valid email address.';
        else if ((getData()?.users || []).some(u => normalizeEmail(u.email) === normalizeEmail(raw))) message = 'An account already exists with this email.';
        break;
      case 'reg-password':
        if (!raw) message = 'Password is required.';
        else if (!strongPassword(raw)) message = 'Use 8–64 characters with uppercase, lowercase, a number, a symbol and no spaces.';
        break;
      case 'reg-confirm':
        if (!raw) message = 'Please confirm your password.';
        else if (raw !== ($('#reg-password')?.value || '')) message = 'Passwords do not match.';
        break;
      case 'reg-course':
        if (!value) message = 'Course / branch is required.';
        else if (value.length < 2 || value.length > 70) message = 'Course must be 2–70 characters.';
        else if (!/^[\p{L}\p{N} .,&()+'/\-]+$/u.test(value)) message = 'Enter a valid course or branch name.';
        break;
      case 'reg-semester':
        if (!/^[1-8]$/.test(raw)) message = 'Choose a semester from 1 to 8.';
        break;
      case 'reg-terms':
        if (!input?.checked) message = 'Please accept the browser-only demo notice.';
        break;
    }
    errorFor(id, message);
    return !message;
  }

  function wireValidation(ids, validate) {
    for (const id of ids) {
      const input = $('#' + id);
      if (!input) continue;
      input.addEventListener('blur', () => validate(id));
      input.addEventListener(input.type === 'checkbox' || input.tagName === 'SELECT' ? 'change' : 'input', () => {
        if (input.classList.contains('is-invalid')) validate(id);
        const formName = page === 'register' ? 'register' : 'login';
        banner(formName, '');
        if (id === 'reg-password') {
          passwordHint();
          if ($('#reg-confirm')?.value) checkRegister('reg-confirm');
        }
      });
    }
  }
  function verifyFields(ids, validate) {
    const checks = ids.map(id => validate(id));
    if (checks.some(ok => !ok)) $('#' + ids[checks.indexOf(false)])?.focus();
    return checks.every(Boolean);
  }

  function rememberSession(userId, remember) {
    const value = JSON.stringify({userId});
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
    if (remember) localStorage.setItem(SESSION_KEY, value);
    else sessionStorage.setItem(SESSION_KEY, value);
  }
  function existingSession() {
    try {
      const stored = sessionStorage.getItem(SESSION_KEY) || localStorage.getItem(SESSION_KEY);
      const session = JSON.parse(stored || 'null');
      return (getData()?.users || []).find(u => u.id === session?.userId && u.status === 'Active');
    } catch (_) { return null; }
  }
  function redirectSignedIn() {
    const already = existingSession();
    if (!already) return false;
    window.location.replace(already.role === 'admin' ? 'admin-dashboard.html' : '../Client/dashboard.html');
    return true;
  }

  function loadFailures() {
    try { return JSON.parse(sessionStorage.getItem(FAIL_KEY) || '{}') || {}; }
    catch (_) { return {}; }
  }
  function failState(key) {
    const data = loadFailures(), state = data[key] || {n:0, blockedUntil:0};
    if (state.blockedUntil && Date.now() >= state.blockedUntil) return {n:0, blockedUntil:0};
    return state;
  }
  function recordFailure(key) {
    const failures = loadFailures();
    const previous = failState(key), n = previous.n + 1;
    failures[key] = {n, blockedUntil:n >= 5 ? Date.now() + 30_000 : 0};
    sessionStorage.setItem(FAIL_KEY, JSON.stringify(failures));
    return failures[key];
  }
  function clearFailures(key) {
    const data = loadFailures(); delete data[key];
    sessionStorage.setItem(FAIL_KEY, JSON.stringify(data));
  }

  function setupLogin() {
    if (redirectSignedIn()) return;
    const ids = ['login-email', 'login-password', 'login-phone'];
    wireValidation(ids, checkLogin);
    $('#login-form')?.addEventListener('submit', event => {
      event.preventDefault();
      banner('login', '');
      if (!verifyFields(ids, checkLogin)) {
        banner('login', 'Check the highlighted fields and try again.');
        return;
      }
      const email = normalizeEmail($('#login-email').value);
      const pwd = $('#login-password').value;
      const key = `${loginRole}:${email}`;
      const state = failState(key);
      if (state.blockedUntil > Date.now()) {
        const remaining = Math.ceil((state.blockedUntil - Date.now()) / 1000);
        banner('login', `Too many attempts. Try again in ${remaining} seconds.`);
        return;
      }
      const data = getData();
      const account = (data?.users || []).find(u => normalizeEmail(u.email) === email && u.role === loginRole && u.password === pwd);
      if (!account) {
        const fails = recordFailure(key);
        banner('login', fails.blockedUntil ? 'Too many incorrect attempts. This browser is temporarily paused for 30 seconds.' : 'Incorrect email or password for this portal. Check your details and try again.');
        errorFor('login-password', 'The email and password combination was not accepted.');
        $('#login-password')?.focus();
        return;
      }
      if (account.status !== 'Active') {
        banner('login', 'This demo account is inactive. Ask the administrator to activate it.');
        return;
      }
      try { rememberSession(account.id, $('#remember-login')?.checked || false); }
      catch (_) { banner('login', 'Browser storage is blocked. Enable browser storage and try again.'); return; }
      clearFailures(key);
      window.location.assign(loginRole === 'admin' ? 'admin-dashboard.html' : '../Client/dashboard.html');
    });
    $('#login-email')?.addEventListener('change', e => {e.target.value=normalizeEmail(e.target.value);});
    $('[data-action="fill-demo"]')?.addEventListener('click', () => {
      // Mobile is not part of the demo account; reset an invalid sample number.
      if ($('#login-phone')) $('#login-phone').value = '';
      for (const id of ids) {errorFor(id, '');}
      banner('login','');
    });
  }

  function setupRegister() {
    if (redirectSignedIn()) return;
    const ids = ['reg-name','reg-email','reg-password','reg-confirm','reg-course','reg-semester','reg-terms'];
    wireValidation(ids, checkRegister);
    passwordHint();
    $('#register-form')?.addEventListener('submit', event => {
      event.preventDefault();
      banner('register', '');
      passwordHint();
      if (!verifyFields(ids, checkRegister)) {
        banner('register', 'Please fix the highlighted fields before creating your account.');
        return;
      }
      const data = getData();
      if (!data || !Array.isArray(data.users)) {
        banner('register', 'Local demo data is unavailable. Reload the website and try again.');
        return;
      }
      const email = normalizeEmail($('#reg-email').value);
      if (data.users.some(u => normalizeEmail(u.email) === email)) {
        errorFor('reg-email', 'An account already exists with this email.');
        $('#reg-email').focus(); return;
      }
      const user = {
        id: 'student_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,9),
        role: 'student', name: $('#reg-name').value.trim().replace(/\s+/g,' '),
        email, password: $('#reg-password').value,
        course: $('#reg-course').value.trim(),
        semester: Number($('#reg-semester').value), status:'Active',
        createdAt: (() => {const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;})()
      };
      data.users.push(user);
      try {
        localStorage.setItem(DATA_KEY, JSON.stringify(data));
        rememberSession(user.id, true);
      } catch (_) {
        banner('register', 'Could not save the account. Browser storage may be disabled or full.');
        return;
      }
      window.location.assign('../Client/dashboard.html');
    });
  }
  const initialize = () => {
    if (page === 'register') setupRegister();
    else setupLogin();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
  else initialize();
})();
