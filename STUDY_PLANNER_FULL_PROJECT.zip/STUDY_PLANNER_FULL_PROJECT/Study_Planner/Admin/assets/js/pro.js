/* Study Planner Pro additions: framework-free browser-side modules.
   Requires only the vanilla JS app.js and local Bootstrap bundle already bundled. */
(() => {
  'use strict';
  const STORAGE = 'studyplanner_pro_v2';
  const BR = window.StudyPlannerBridge;
  const $ = (q, root=document) => root.querySelector(q);
  const $$ = (q, root=document) => Array.from(root.querySelectorAll(q));
  const H = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const id = prefix => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,9)}`;
  const dateStr = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const today = () => dateStr(new Date());
  const moveDate = (day, offset) => {const d=new Date(`${day}T12:00:00`); d.setDate(d.getDate()+offset); return dateStr(d);};
  const daysBetween = (a,b) => Math.round((Date.parse(`${a}T12:00:00`)-Date.parse(`${b}T12:00:00`))/86400000);
  const labelDate = d => d ? new Date(`${d}T12:00:00`).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}) : '—';
  const num = n => (Math.round(Number(n||0)*100)/100).toLocaleString('en-IN',{maximumFractionDigits:2});
  const hours = (arr) => arr.reduce((s,x)=>s+(Number(x.hours)||0),0);
  const setText = (key,text) => {const el=$('#'+key);if(el)el.textContent=String(text);};
  const setHTML = (key,value) => {const el=$('#'+key);if(el)el.innerHTML=value;};
  const notice = msg => {if(BR && typeof BR.toast==='function')BR.toast(msg);else alert(msg);};
  const DAY_NAMES=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const themeKey='studyplanner_theme_v2';
  let pro = loadPro();
  let focusInterval=null;
  let isRendering=false;
  const getData = () => BR?.getData?.() || null;
  const current = () => BR?.getUser?.() || null;
  const userId = () => current()?.id || null;
  const studentSubs = () => (getData()?.subjects||[]).filter(s=>s.userId===userId());
  const studentTasks = () => (getData()?.tasks||[]).filter(s=>s.userId===userId());
  const studentPlans = () => (getData()?.plans||[]).filter(s=>s.userId===userId());
  const studentSessions = () => (getData()?.sessions||[]).filter(s=>s.userId===userId());
  const subName = sid => (getData()?.subjects||[]).find(s=>s.id===sid)?.name||'General';
  const subColor = sid => (getData()?.subjects||[]).find(s=>s.id===sid)?.color||'#6483c7';
  function loadPro(){
    try{const saved=JSON.parse(localStorage.getItem(STORAGE));if(saved&&saved.version===2&&saved.users&&Array.isArray(saved.announcements))return saved;}catch(_e){}
    return {version:2,users:{},announcements:[
      {id:'a_welcome',title:'Welcome to Study Planner Pro',body:'Plan your week, track your focus sessions and make steady progress every day.',date:today()},
      {id:'a_reminder',title:'Your progress is in your hands',body:'Review upcoming tasks and keep your study notes ready before exams.',date:today()}
    ]};
  }
  function persist(){try{localStorage.setItem(STORAGE,JSON.stringify(pro));}catch(err){notice('Browser storage is full. Export a backup and free up some storage.');}}
  function userState(uid=userId()){
    if(!uid)return null;
    if(!pro.users[uid]){
      pro.users[uid]={goal:2,exams:[],timetable:[],notes:[],habits:[],habitChecks:{},focusCompleted:0,timer:null,notifDay:''};
      if(uid==='student_demo'){
        pro.users[uid].exams=[{id:'exam_example',title:'Database Management – Internal Test',subjectId:'s2',date:moveDate(today(),5)}];
        pro.users[uid].timetable=[
          {id:'tt_sample1',day:1,title:'SQL practice',subjectId:'s2',start:'18:00',end:'19:00'},
          {id:'tt_sample2',day:3,title:'Data structures revision',subjectId:'s1',start:'17:00',end:'18:30'},
          {id:'tt_sample3',day:5,title:'Web project coding',subjectId:'s5',start:'10:00',end:'12:00'}
        ];
        pro.users[uid].notes=[{id:'note_sample',subjectId:'s2',title:'Normalization quick revision',body:'1NF: atomic values. 2NF: remove partial dependencies. 3NF: remove transitive dependencies. Practice with your own table examples.',updatedAt:today()}];
        pro.users[uid].habits=[{id:'habit_sample1',name:'Daily revision'},{id:'habit_sample2',name:'Practice coding'}];
        pro.users[uid].habitChecks={'habit_sample1':[moveDate(today(),-2),moveDate(today(),-1)],'habit_sample2':[moveDate(today(),-1)]};
      }
      persist();
    }
    const u=pro.users[uid];
    u.exams ||= [];u.timetable ||= [];u.notes ||= [];u.habits ||= [];u.habitChecks ||= {};
    if(!(Number(u.goal)>0))u.goal=2;
    return u;
  }
  function themeApply(){
    const theme=localStorage.getItem(themeKey)==='dark'?'dark':'light';
    document.documentElement.dataset.theme=theme;
    $$('.pro-theme-toggle').forEach(b=>{b.textContent=theme==='dark'?'☀️ Light mode':'🌙 Dark mode';b.setAttribute('aria-pressed',String(theme==='dark'));});
  }
  function themeToggle(){localStorage.setItem(themeKey,document.documentElement.dataset.theme==='dark'?'light':'dark');themeApply();}
  function dayHours(day, uid=userId()){
    return hours((getData()?.sessions||[]).filter(x=>x.userId===uid && x.date===day));
  }
  function streak(uid=userId()){
    const active=new Set((getData()?.sessions||[]).filter(s=>s.userId===uid && Number(s.hours)>0).map(s=>s.date));
    let key=active.has(today())?today():moveDate(today(),-1),days=0;
    while(active.has(key)&&days<3660){days++;key=moveDate(key,-1);}
    return days;
  }
  function subjectOptions(selectId){
    const target=$('#'+selectId);if(!target)return;
    const previous=target.value;
    target.innerHTML=studentSubs().map(s=>`<option value="${H(s.id)}">${H(s.name)}</option>`).join('');
    if(studentSubs().some(s=>s.id===previous))target.value=previous;
  }
  function renderGoals(){
    const u=userState();if(!u)return;
    const actual=dayHours(today()), pct=Math.max(0,Math.min(100,actual/u.goal*100));
    setText('pro-goal-hours',`${num(actual)} / ${num(u.goal)} h`);
    setText('pro-goal-status',actual>=u.goal?'Goal reached 🎉':`${num(Math.max(0,u.goal-actual))} h left`);
    const bar=$('#pro-goal-bar');if(bar){bar.style.width=`${pct}%`;bar.setAttribute('aria-valuenow',String(Math.round(pct)));bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax','100');}
    const input=$('#goal-target');if(input && document.activeElement!==input)input.value=u.goal;
  }
  function renderStreak(){
    const count=streak(),days=Array.from({length:7},(_,i)=>moveDate(today(),i-6));
    setText('pro-streak-count',`${count} day${count===1?'':'s'}`);
    setText('progress-streak',`${count} day${count===1?'':'s'}`);
    setText('pro-streak-caption',count>=3?'Excellent consistency!':'One study session each day builds momentum.');
    setText('progress-streak-detail',count>=7?'A full week of consistency!':'Log study sessions on consecutive days to grow your streak.');
    const chips=days.map(d=>`<span class="pro-day-dot ${dayHours(d)>0?'done':''}" title="${H(labelDate(d))}: ${num(dayHours(d))} hours"><strong>${H(new Date(`${d}T12:00:00`).toLocaleDateString('en-IN',{weekday:'short'}))}</strong><span>${dayHours(d)>0?'✓':'·'}</span></span>`).join('');
    setHTML('pro-week-dots',chips);setHTML('progress-streak-calendar',chips);
  }
  function sortedExams(){return userState()?.exams.filter(e=>e.date>=today()).sort((a,b)=>a.date.localeCompare(b.date))||[];}
  function renderExams(){
    if(!userId())return;
    const next=sortedExams()[0];
    setHTML('pro-next-exam',next?`<div class="d-flex align-items-center justify-content-between gap-2"><div><strong class="pro-exam-title">${H(next.title)}</strong><div class="text-muted small">${H(subName(next.subjectId))} · ${H(labelDate(next.date))}</div></div><div class="pro-countdown"><strong>${daysBetween(next.date,today())}</strong><small>days left</small></div></div>`:`<div class="empty-state"><strong>No upcoming exams</strong><span>Add an exam in your Study Plan.</span></div>`);
    const exams=userState().exams.slice().sort((a,b)=>a.date.localeCompare(b.date));
    setText('exam-count',`${exams.length} exam${exams.length===1?'':'s'}`);
    setHTML('exam-list',exams.length?exams.map(ex=>`<article class="pro-list-item"><div class="min-0"><strong>${H(ex.title)}</strong><p class="mb-0 text-muted small">${H(subName(ex.subjectId))} · ${labelDate(ex.date)} · ${daysBetween(ex.date,today())<0?'Past exam':`${daysBetween(ex.date,today())} days left`}</p></div><div class="d-flex gap-1"><button type="button" class="icon-btn" data-pro-action="edit-exam" data-id="${H(ex.id)}" aria-label="Edit exam">✎</button><button type="button" class="icon-btn" data-pro-action="delete-exam" data-id="${H(ex.id)}" aria-label="Delete exam">×</button></div></article>`).join(''):`<p class="text-muted small">No exams added. Add your next exam above.</p>`);
  }
  function renderSuggestions(){
    if(!$('#pro-suggestions'))return;
    const items=studentTasks().filter(t=>t.status!=='Completed').map(t=>{
      const distance=daysBetween(t.due,today());
      const score=(t.priority==='High'?50:t.priority==='Medium'?20:5) + (distance<0?100:distance===0?75:distance<=2?35:Math.max(0,15-distance)) + (t.status==='In Progress'?5:0);
      return {...t,score,distance};
    }).sort((a,b)=>b.score-a.score || a.due.localeCompare(b.due)).slice(0,4);
    setHTML('pro-suggestions',items.length?items.map((t,i)=>`<div class="pro-suggestion"><span class="pro-suggestion-rank">${i+1}</span><div class="flex-grow-1 min-0"><strong>${H(t.title)}</strong><div class="small text-muted">${H(subName(t.subjectId))} · ${H(t.priority)} priority · ${t.distance<0?`${-t.distance} day(s) overdue`:t.distance===0?'Due today':`Due in ${t.distance} day(s)`}</div></div><button class="btn btn-sm btn-light" type="button" data-pro-action="task-jump" data-id="${H(t.id)}">Open</button></div>`).join(''):`<div class="empty-state"><strong>All caught up! 🎉</strong><span>You've completed your open tasks.</span></div>`);
  }
  function renderAnnouncements(){
    const all=pro.announcements.slice().sort((a,b)=>String(b.createdAt||b.date).localeCompare(String(a.createdAt||a.date)));
    setHTML('pro-announcements-student',all.length?all.slice(0,4).map(a=>`<article class="pro-announcement"><div><span class="badge badge-soft-primary">ADMIN NOTICE</span><strong>${H(a.title)}</strong><p class="text-muted small mb-0">${H(a.body)}</p></div><time class="text-muted small flex-shrink-0">${H(labelDate(a.date))}</time></article>`).join(''):`<p class="text-muted small mb-0">No announcements yet.</p>`);
    setHTML('announcement-admin-list',all.length?all.map(a=>`<article class="pro-list-item"><div class="min-0"><strong>${H(a.title)}</strong><p class="text-muted small mb-0">${H(a.body)} · ${H(labelDate(a.date))}</p></div><div class="d-flex gap-1"><button class="icon-btn" data-pro-action="edit-announcement" data-id="${H(a.id)}" type="button" aria-label="Edit announcement">✎</button><button class="icon-btn" data-pro-action="delete-announcement" data-id="${H(a.id)}" type="button" aria-label="Delete announcement">×</button></div></article>`).join(''):`<p class="text-muted small">No announcements published.</p>`);
  }
  function formatTime(t){if(!t)return '—';const [hh,mm]=t.split(':').map(Number);return `${hh%12||12}:${String(mm).padStart(2,'0')} ${hh>=12?'PM':'AM'}`;}
  function renderTimetable(){
    if(!$('#timetable-rows'))return;
    const u=userState(),entries=u.timetable.slice().sort((a,b)=>((a.day+6)%7)-((b.day+6)%7)||a.start.localeCompare(b.start));
    setText('timetable-count',`${entries.length} slot${entries.length===1?'':'s'}`);
    setHTML('timetable-rows',entries.length?entries.map(t=>`<tr><td class="fw-semibold">${DAY_NAMES[t.day]}</td><td><strong>${H(t.title)}</strong><br><span class="text-muted small">${H(subName(t.subjectId))}</span></td><td class="small">${formatTime(t.start)} – ${formatTime(t.end)}</td><td><div class="d-flex gap-1"><button class="icon-btn" type="button" data-pro-action="edit-timetable" data-id="${H(t.id)}" aria-label="Edit timetable slot">✎</button><button class="icon-btn" type="button" data-pro-action="delete-timetable" data-id="${H(t.id)}" aria-label="Delete timetable slot">×</button></div></td></tr>`).join(''):`<tr><td colspan="4" class="text-muted text-center">No timetable slots yet.</td></tr>`);
  }
  function renderEvents(){
    const picker=$('#event-date');if(!picker)return;
    if(!picker.value)picker.value=today();const d=picker.value;
    const evt=[];
    studentTasks().filter(t=>t.due===d).forEach(t=>evt.push({kind:'Task',label:t.title,detail:`${subName(t.subjectId)} · ${t.status}`,color:'orange'}));
    studentPlans().filter(p=>p.date===d).forEach(p=>evt.push({kind:'Study plan',label:p.title,detail:`${subName(p.subjectId)} · ${formatTime(p.start)}`,color:'blue'}));
    userState().exams.filter(e=>e.date===d).forEach(e=>evt.push({kind:'Exam',label:e.title,detail:subName(e.subjectId),color:'red'}));
    const day=new Date(`${d}T12:00:00`).getDay();
    userState().timetable.filter(t=>t.day===day).forEach(t=>evt.push({kind:'Weekly slot',label:t.title,detail:`${subName(t.subjectId)} · ${formatTime(t.start)}`,color:'green'}));
    setHTML('calendar-event-list',evt.length?evt.map(e=>`<div class="pro-event"><span class="pro-event-dot ${e.color}"></span><div><strong>${H(e.label)}</strong><p class="mb-0 text-muted small">${H(e.kind)} · ${H(e.detail)}</p></div></div>`).join(''):`<div class="empty-state"><strong>No events for ${labelDate(d)}</strong><span>Use the forms above to add plans and exams.</span></div>`);
  }
  function renderNotes(){
    if(!$('#notes-list'))return;
    const u=userState(),q=($('#note-search')?.value||'').toLowerCase().trim();
    const notes=u.notes.filter(n=>`${n.title} ${n.body} ${subName(n.subjectId)}`.toLowerCase().includes(q)).sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)));
    setText('notes-count',`${u.notes.length} note${u.notes.length===1?'':'s'}`);
    setHTML('notes-list',notes.length?notes.map(n=>`<article class="pro-note-card"><div class="d-flex align-items-start justify-content-between gap-2"><div class="min-0"><span class="badge badge-soft-primary mb-2">${H(subName(n.subjectId))}</span><h3>${H(n.title)}</h3></div><div class="d-flex gap-1"><button type="button" class="icon-btn" data-pro-action="edit-note" data-id="${H(n.id)}" title="Edit note">✎</button><button type="button" class="icon-btn" data-pro-action="delete-note" data-id="${H(n.id)}" title="Delete note">×</button></div></div><p class="pro-note-body">${H(n.body)}</p><small class="text-muted">Updated ${H(labelDate(n.updatedAt))}</small></article>`).join(''):`<div class="empty-state"><strong>No notes found</strong><span>Add your first revision note.</span></div>`);
  }
  function clearNoteForm(){
    $('#note-form')?.reset();if($('#note-id'))$('#note-id').value='';
    setText('note-submit','Save note');
  }
  function urgency(t){
    const delta=daysBetween(t.due,today());return t.status==='Completed'?'done':delta<0?'overdue':delta===0?'today':delta<=2?'soon':'';
  }
  function renderKanban(){
    if(!$('#kanban-board'))return;
    const tasks=studentTasks();
    [['Pending','kb-pending','kb-pending-count'],['In Progress','kb-progress','kb-progress-count'],['Completed','kb-completed','kb-completed-count']].forEach(([status,target,countId])=>{
      const filtered=tasks.filter(t=>t.status===status).sort((a,b)=>({High:0,Medium:1,Low:2}[a.priority]||1)-({High:0,Medium:1,Low:2}[b.priority]||1) || String(a.due).localeCompare(String(b.due)));
      setText(countId,filtered.length);
      setHTML(target,filtered.length?filtered.map(t=>`<article class="kanban-card ${urgency(t)}" draggable="true" data-task-id="${H(t.id)}" tabindex="0"><div class="d-flex justify-content-between align-items-start gap-2"><span class="pro-priority priority-${H(t.priority).toLowerCase()}">${H(t.priority)}</span><button class="icon-btn" type="button" data-action="edit-task" data-id="${H(t.id)}" aria-label="Edit task">✎</button></div><strong>${H(t.title)}</strong><p class="text-muted small mb-1">${H(subName(t.subjectId))}</p><div class="d-flex flex-wrap align-items-center justify-content-between gap-1"><small class="${urgency(t)==='overdue'?'text-danger fw-bold':'text-muted'}">📅 ${H(labelDate(t.due))}${urgency(t)==='overdue'?' · Overdue':''}</small><select class="form-select form-select-sm kanban-status" data-pro-status-id="${H(t.id)}" aria-label="Task status"><option value="Pending" ${status==='Pending'?'selected':''}>To do</option><option value="In Progress" ${status==='In Progress'?'selected':''}>In progress</option><option value="Completed" ${status==='Completed'?'selected':''}>Completed</option></select></div></article>`).join(''):`<div class="kanban-empty">Drop tasks here</div>`);
    });
  }
  function setTaskStatus(taskId,status){
    const t=studentTasks().find(t=>t.id===taskId);
    if(!t||!['Pending','In Progress','Completed'].includes(status))return;
    if(t.status===status)return;
    t.status=status;t.completedAt=status==='Completed'?today():null;
    BR.save();BR.refresh();renderAll();notice('Task moved to '+status+'.');
  }
  function renderLogHistory(){
    if(!$('#study-log-rows'))return;
    const list=studentSessions().slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,60);
    setText('log-history-count',`${studentSessions().length} entries`);
    setHTML('study-log-rows',list.length?list.map(item=>`<tr><td>${H(labelDate(item.date))}</td><td>${H(subName(item.subjectId))}</td><td><strong>${num(item.hours)} h</strong></td><td>${item.source==='pomodoro'?'⏱ Timer':'✍️ Manual'}</td><td><div class="d-flex gap-1"><button type="button" class="icon-btn" data-action="edit-log" data-id="${H(item.id)}" title="Edit study log" aria-label="Edit study log">✎</button><button type="button" class="icon-btn" data-action="delete-log" data-id="${H(item.id)}" title="Delete study log" aria-label="Delete study log">×</button></div></td></tr>`).join(''):'<tr><td colspan="5" class="text-center text-muted py-4">No logged study hours yet. Click Log Study Hours to get started.</td></tr>');
  }
  function renderHabits(){
    if(!$('#habit-table'))return;
    const u=userState(),dates=Array.from({length:7},(_,i)=>moveDate(today(),i-6));
    setHTML('habit-head',`<tr><th>Habit</th>${dates.map(d=>`<th class="text-center" title="${H(labelDate(d))}">${H(new Date(`${d}T12:00:00`).toLocaleDateString('en-IN',{weekday:'short'}))}</th>`).join('')}<th></th></tr>`);
    setHTML('habit-table',u.habits.length?u.habits.map(h=>`<tr><td><strong>${H(h.name)}</strong></td>${dates.map(d=>{const checked=(u.habitChecks[h.id]||[]).includes(d);return `<td class="text-center"><button type="button" data-pro-action="toggle-habit" data-id="${H(h.id)}" data-day="${d}" class="habit-check ${checked?'checked':''}" aria-label="${checked?'Unmark':'Mark'} ${H(h.name)} for ${H(labelDate(d))}" aria-pressed="${checked}">${checked?'✓':'·'}</button></td>`;}).join('')}<td><button class="icon-btn" type="button" data-pro-action="delete-habit" data-id="${H(h.id)}" aria-label="Delete habit">×</button></td></tr>`).join(''):`<tr><td colspan="9" class="text-muted text-center">Add a habit to start tracking.</td></tr>`);
    const done=u.habits.filter(h=>(u.habitChecks[h.id]||[]).includes(today())).length;
    setText('habit-summary',`${done}/${u.habits.length} today`);
  }
  function renderBadges(){
    if(!$('#achievement-grid'))return;
    const tasks=studentTasks(),total=hours(studentSessions()),s=streak(),u=userState(),done=tasks.filter(t=>t.status==='Completed').length;
    const badges=[
      ['🌱','First Step','Log 1 study hour',total>=1],
      ['🔥','3-Day Streak','Study on 3 consecutive days',s>=3],
      ['🏆','7-Day Streak','Study on 7 consecutive days',s>=7],
      ['✅','Task Finisher','Complete 5 tasks',done>=5],
      ['📚','Well Organized','Add 3 subjects',studentSubs().length>=3],
      ['⏱','Focus Champion','Finish a Pomodoro focus',Number(u.focusCompleted)>=1],
      ['🗒','Note Taker','Save 3 study notes',u.notes.length>=3],
      ['🎯','Goal Crusher','Reach today’s study goal',dayHours(today())>=u.goal],
      ['💪','Deep Learner','Log 20 study hours',total>=20]
    ];
    setText('badge-earned',`${badges.filter(x=>x[3]).length}/${badges.length} earned`);
    setHTML('achievement-grid',badges.map(b=>`<div class="col-sm-6"><div class="pro-badge ${b[3]?'earned':'locked'}"><span>${b[0]}</span><div><strong>${H(b[1])}</strong><small>${H(b[2])}</small></div><span class="badge ${b[3]?'badge-soft-success':'badge-soft-gray'}">${b[3]?'Earned':'Locked'}</span></div></div>`).join(''));
  }
  function trendBars(values,dates){
    const max=Math.max(1,...values);
    return `<div class="pro-bars">${values.map((v,i)=>`<div class="pro-bar-column"><span title="${H(labelDate(dates[i]))}: ${num(v)} hours" class="pro-bar" style="height:${Math.max(4,v/max*100)}%"></span><small>${i%2===0?new Date(`${dates[i]}T12:00:00`).toLocaleDateString('en-IN',{day:'numeric',month:'short'}):'·'}</small></div>`).join('')}</div>`;
  }
  function renderInsights(){
    if(!$('#insights-bars'))return;
    const dates=Array.from({length:14},(_,i)=>moveDate(today(),i-13));
    const values=dates.map(d=>dayHours(d));
    const thisWeek=values.slice(7).reduce((s,v)=>s+v,0),lastWeek=values.slice(0,7).reduce((s,v)=>s+v,0);
    const lastWeekDelta=lastWeek>0?`${thisWeek>=lastWeek?'+':''}${num((thisWeek-lastWeek)/lastWeek*100)}%`:thisWeek>0?'New activity':'0%';
    setText('insights-this-week',num(thisWeek)+' h');
    setText('insights-week-change',lastWeekDelta);
    const top=values.indexOf(Math.max(...values));
    setText('insights-best-day',num(values[top])+' h · '+new Date(`${dates[top]}T12:00:00`).toLocaleDateString('en-IN',{weekday:'short'}));
    const goalMet=dates.filter(d=>dayHours(d)>=userState().goal).length;
    setText('insights-goal-rate',Math.round(goalMet/14*100)+'%');
    setHTML('insights-bars',trendBars(values,dates));
    const subs=studentSubs().slice().sort((a,b)=>hours(studentSessions().filter(t=>t.subjectId===b.id))-hours(studentSessions().filter(t=>t.subjectId===a.id)));
    const max=Math.max(1,...subs.map(s=>hours(studentSessions().filter(x=>x.subjectId===s.id))));
    setHTML('subject-comparison',subs.length?subs.map(s=>{const value=hours(studentSessions().filter(x=>x.subjectId===s.id));return `<div class="pro-compare"><div class="d-flex justify-content-between gap-2"><strong>${H(s.name)}</strong><span>${num(value)} / ${num(s.target)} h</span></div><div class="progress"><div class="progress-bar" style="width:${Math.min(100,value/max*100)}%;background:${/^#[0-9a-f]{6}$/i.test(s.color)?s.color:'#426be8'}"></div></div></div>`;}).join(''):`<p class="text-muted small">No subject hours logged yet.</p>`);
  }
  function performance(uid){
    const d=getData(),tasks=d.tasks.filter(t=>t.userId===uid),logs=d.sessions.filter(t=>t.userId===uid);
    const done=tasks.filter(t=>t.status==='Completed').length;
    return {uid,studyHours:hours(logs),done,tasks:tasks.length,completion:tasks.length?Math.round(done/tasks.length*100):0,streak:streak(uid),last:logs.length?logs.map(x=>x.date).sort().at(-1):''};
  }
  function renderPerformance(){
    const d=getData();if(!d||!current()||current().role!=='admin')return;
    const all=d.users.filter(u=>u.role==='student').map(u=>({...u,...performance(u.id)}));
    const sort=$('#performance-sort')?.value||'hours';
    if(sort==='name')all.sort((a,b)=>a.name.localeCompare(b.name));
    else all.sort((a,b)=>sort==='completion'?b.completion-a.completion:sort==='streak'?b.streak-a.streak:b.studyHours-a.studyHours);
    setHTML('student-performance-rows',all.length?all.map(u=>`<tr><td><strong>${H(u.name)}</strong><br><small class="text-muted">${H(u.course)}</small></td><td>${num(u.studyHours)} h</td><td>${u.done}/${u.tasks}</td><td><div class="d-flex align-items-center gap-2"><div class="progress pro-table-progress flex-grow-1"><div class="progress-bar" style="width:${u.completion}%"></div></div><small>${u.completion}%</small></div></td><td>🔥 ${u.streak}d</td><td>${H(labelDate(u.last))}</td></tr>`).join(''):`<tr><td colspan="6" class="text-muted text-center">No students available.</td></tr>`);
    setHTML('admin-leaderboard',all.slice().sort((a,b)=>b.studyHours-a.studyHours).slice(0,5).map((u,i)=>`<div class="pro-leader-row"><span class="pro-suggestion-rank">${i+1}</span><div class="flex-grow-1 min-0"><strong>${H(u.name)}</strong><small class="d-block text-muted">${u.completion}% task completion · 🔥 ${u.streak}d streak</small></div><strong class="text-primary">${num(u.studyHours)} h</strong></div>`).join('')||'<p class="text-muted small">No students yet.</p>');
  }
  function renderAdminExtras(){
    if(!current()||current().role!=='admin')return;
    const d=getData(),all=d.subjects.slice().sort((a,b)=>hours(d.sessions.filter(x=>x.subjectId===b.id))-hours(d.sessions.filter(x=>x.subjectId===a.id)));
    setHTML('admin-subject-progress',all.slice(0,8).map(s=>{const n=hours(d.sessions.filter(x=>x.subjectId===s.id)),pct=Math.min(100,Math.round(n/Math.max(1,Number(s.target))*100));return `<div class="pro-compare"><div class="d-flex justify-content-between"><strong>${H(s.name)} <small class="text-muted">· ${H(d.users.find(u=>u.id===s.userId)?.name||'Student')}</small></strong><span>${num(n)} / ${num(s.target)} h</span></div><div class="progress"><div class="progress-bar" style="width:${pct}%"></div></div></div>`;}).join('')||'<p class="text-muted small">No subjects yet.</p>');
    const watch=d.tasks.filter(t=>t.status!=='Completed'&&daysBetween(t.due,today())<=7).sort((a,b)=>a.due.localeCompare(b.due)).slice(0,8);
    setHTML('admin-deadline-watch',watch.length?watch.map(t=>`<div class="pro-event"><span class="pro-event-dot ${t.due<today()?'red':'orange'}"></span><div><strong>${H(t.title)}</strong><p class="mb-0 small text-muted">${H(d.users.find(u=>u.id===t.userId)?.name||'Student')} · ${H(subName(t.subjectId))} · ${H(labelDate(t.due))}</p></div><span class="badge ${t.due<today()?'badge-soft-danger':'badge-soft-warning'}">${t.due<today()?'Overdue':H(t.priority)}</span></div>`).join(''):'<p class="text-muted small mb-0">No urgent deadlines at the moment.</p>');
    const dates=Array.from({length:14},(_,i)=>moveDate(today(),i-13));
    const values=dates.map(date=>hours(d.sessions.filter(s=>s.date===date)));
    const a=values.slice(7).reduce((s,v)=>s+v,0),b=values.slice(0,7).reduce((s,v)=>s+v,0);
    setText('class-week-hours',num(a)+' h');
    setText('class-week-delta',b?`${a>=b?'+':''}${num((a-b)/b*100)}%`:a>0?'New activity':'0%');
    setText('class-active-today',new Set(d.sessions.filter(s=>s.date===today()).map(s=>s.userId)).size);
    setText('class-high-priority',d.tasks.filter(t=>t.status!=='Completed'&&t.priority==='High').length);
    setHTML('class-trend',trendBars(values,dates));
  }
  function renderAll(){
    if(isRendering||!getData()||!current())return;
    isRendering=true;
    try{
      if(current().role==='student'){
        const u=userState();
        ['focus-subject','timetable-subject','exam-subject','note-subject'].forEach(subjectOptions);
        renderGoals();renderStreak();renderExams();renderSuggestions();renderTimetable();renderEvents();renderNotes();renderKanban();renderLogHistory();renderHabits();renderBadges();renderInsights();
        updateFocusUI(u);
      }
      renderAnnouncements();renderPerformance();renderAdminExtras();
      updateNotificationLabel();
    }finally{isRendering=false;}
  }
  function startFocus(){
    const u=userState(),t=getTimer(u);
    if(t.running)return;
    if(t.mode==='focus'&&!studentSubs().length){notice('Add a subject first so the focus session can be logged.');return;}
    t.subjectId=$('#focus-subject')?.value||t.subjectId;
    t.running=true;t.endAt=Date.now()+Math.max(1,t.remaining)*1000;
    persist();tickFocus();
  }
  function getTimer(u=userState()){
    if(!u)return null;
    if(!u.timer || !['focus','break5','break15'].includes(u.timer.mode))u.timer={mode:'focus',duration:25*60,remaining:25*60,running:false,endAt:null,subjectId:null};
    return u.timer;
  }
  function focusSeconds(t){return t.running ? Math.max(0,Math.ceil((t.endAt-Date.now())/1000)):t.remaining;}
  function modeDuration(mode){return mode==='focus'?25*60:mode==='break5'?5*60:15*60;}
  function chooseFocus(mode){
    const u=userState();if(!u)return;
    const t=getTimer(u),seconds=focusSeconds(t);
    if(t.running && seconds>0 && !confirm('Change timer mode and discard the current countdown?'))return;
    t.mode=mode;t.duration=modeDuration(mode);t.remaining=t.duration;t.running=false;t.endAt=null;
    persist();updateFocusUI(u);
  }
  function pauseFocus(){const t=getTimer();if(!t||!t.running)return;t.remaining=focusSeconds(t);t.running=false;t.endAt=null;persist();updateFocusUI(userState());}
  function resetFocus(){const t=getTimer();if(!t)return;t.remaining=t.duration;t.running=false;t.endAt=null;persist();updateFocusUI(userState());}
  function updateFocusUI(u){
    const t=u&&getTimer(u);if(!t||!$('#focus-ring'))return;
    const remaining=focusSeconds(t),min=String(Math.floor(remaining/60)).padStart(2,'0'),sec=String(remaining%60).padStart(2,'0');
    setText('focus-clock-text',`${min}:${sec}`);
    setText('focus-clock-subtitle',t.running?'Stay with it':remaining<t.duration?'Paused — resume anytime':'Ready to focus');
    setText('focus-mode-label',t.mode==='focus'?'FOCUS':'BREAK');
    const ring=$('#focus-ring');ring.style.setProperty('--timer-percent',`${Math.round((1-remaining/Math.max(1,t.duration))*100)}%`);
    $$('.pro-mode').forEach(b=>{const matching=Number(b.dataset.focusMode)=== (t.mode==='focus'?25:t.mode==='break5'?5:15);b.classList.toggle('active',matching);b.classList.toggle('btn-outline-primary',matching);b.classList.toggle('btn-light',!matching);});
    const sb=$('#focus-start'),pb=$('#focus-pause');if(sb){sb.disabled=t.running;sb.textContent=remaining<t.duration?'▶ Resume':'▶ Start';}if(pb)pb.disabled=!t.running;
    const sel=$('#focus-subject');if(sel){if(t.subjectId && [...sel.options].some(o=>o.value===t.subjectId))sel.value=t.subjectId;sel.disabled=t.running;}
  }
  function tickFocus(){
    if(!$('#focus-ring')||!userId())return;
    const u=userState(),t=getTimer(u);
    if(t.running&&focusSeconds(t)<=0){
      const finishedMode=t.mode,sub=t.subjectId,seconds=t.duration;
      t.running=false;t.endAt=null;t.mode=finishedMode==='focus'?'break5':'focus';t.duration=modeDuration(t.mode);t.remaining=t.duration;
      if(finishedMode==='focus'){
        const selected=studentSubs().find(s=>s.id===sub)||studentSubs()[0];
        u.focusCompleted=Number(u.focusCompleted||0)+1;
        if(selected){
          getData().sessions.push({id:id('focus'),userId:userId(),subjectId:selected.id,date:today(),hours:Math.round(seconds/60)/60,source:'pomodoro'});
          BR.save();BR.refresh();
        }
        notice(selected?'Focus complete! Study time was logged. Enjoy your break.':'Focus complete! Add a subject to save study hours.');
      }else notice('Break finished. Ready for the next focus session!');
      persist();renderAll();
      if(typeof Notification!=='undefined'&&Notification.permission==='granted'){
        new Notification('Study Planner Pro',{body:finishedMode==='focus'?'Focus complete. Take a short break!':'Break over. Time to focus.'});
      }
    }
    updateFocusUI(u);
  }
  function notificationAvailable(){return typeof Notification!=='undefined' && window.isSecureContext;}
  function updateNotificationLabel(){
    const b=$('#notification-enable');if(!b)return;
    if(!notificationAvailable()){b.textContent='🔕 Browser alerts unavailable';b.title='Open with Live Server (localhost) or HTTPS for browser notifications';return;}
    b.textContent=Notification.permission==='granted'?'🔔 Alerts on':'🔔 Enable alerts';
  }
  async function enableNotifications(){
    if(!notificationAvailable()){notice('Browser notifications require a compatible browser on HTTPS or localhost. In-app reminders still work.');return;}
    try{
      const permission=await Notification.requestPermission();
      updateNotificationLabel();
      if(permission==='granted'){
        new Notification('Study Planner alerts enabled',{body:'Due tasks and upcoming exams will be checked while the app is open.'});
        const u=userState();if(u)u.notifDay='';
        remindDue();
      }else notice('Notification permission was not granted. You can still see deadlines inside the app.');
    }catch(_e){notice('Your browser could not enable notifications.');}
  }
  function remindDue(){
    if(!notificationAvailable()||Notification.permission!=='granted'||!userId()||current()?.role!=='student')return;
    const u=userState();if(u.notifDay===today())return;
    const taskCount=studentTasks().filter(t=>t.status!=='Completed' && daysBetween(t.due,today())<=1).length;
    const exams=sortedExams().filter(e=>daysBetween(e.date,today())<=3);
    if(taskCount||exams.length){
      const parts=[taskCount?`${taskCount} task(s) due soon or overdue`:'',exams.length?`${exams.length} upcoming exam(s)`:''].filter(Boolean);
      try{new Notification('Your Study Planner reminders',{body:parts.join(' · ')});}catch(_e){}
    }
    u.notifDay=today();persist();
  }
  function downloadJSON(name, payload){
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
    notice('Backup file downloaded.');
  }
  function studentBackup(){
    const d=getData(),uid=userId();if(!uid)return;
    const records={subjects:d.subjects.filter(x=>x.userId===uid),tasks:d.tasks.filter(x=>x.userId===uid),plans:d.plans.filter(x=>x.userId===uid),sessions:d.sessions.filter(x=>x.userId===uid)};
    downloadJSON('study-planner-my-backup.json',{kind:'studyplanner-student-backup-v2',savedAt:new Date().toISOString(),owner:current().name,records,extras:JSON.parse(JSON.stringify(userState()))});
  }
  function adminBackup(){
    if(current()?.role!=='admin')return;
    downloadJSON('study-planner-all-demo-data.json',{kind:'studyplanner-admin-backup-v2',savedAt:new Date().toISOString(),base:getData(),extras:pro});
  }
  function validRecordSet(rows){
    if(!rows||!['subjects','tasks','plans','sessions'].every(k=>Array.isArray(rows[k]) && rows[k].length<=20000))return false;
    return ['subjects','tasks','plans','sessions'].every(k=>rows[k].every(r=>r && typeof r==='object' && typeof r.id==='string' && typeof r.userId==='string'));
  }
  function restoreStudent(saved){
    if(saved?.kind!=='studyplanner-student-backup-v2'||!validRecordSet(saved.records)||!saved.extras||typeof saved.extras!=='object')throw Error('Not a compatible personal backup.');
    const d=getData(),uid=userId();if(!uid||current()?.role!=='student')throw Error('Sign in as a student first.');
    if(!confirm('Replace ALL your local study subjects, tasks, plans, notes and logs with the selected backup? This cannot be undone.'))return;
    const rowMap=new Map();
    const subjects=saved.records.subjects.map(s=>{const newId=id('subject');rowMap.set(s.id,newId);return {...s,id:newId,userId:uid};});
    const mapRecord = (r,k) => ({...r,id:id(k),userId:uid,subjectId:rowMap.get(r.subjectId)||''});
    const tasks=saved.records.tasks.map(r=>mapRecord(r,'task')).filter(r=>r.subjectId);
    const plans=saved.records.plans.map(r=>mapRecord(r,'plan')).filter(r=>r.subjectId);
    const sessions=saved.records.sessions.map(r=>mapRecord(r,'session')).filter(r=>r.subjectId);
    for(const key of ['subjects','tasks','plans','sessions'])d[key]=d[key].filter(r=>r.userId!==uid);
    d.subjects.push(...subjects);d.tasks.push(...tasks);d.plans.push(...plans);d.sessions.push(...sessions);
    const e=JSON.parse(JSON.stringify(saved.extras));
    for(const type of ['notes','timetable','exams'])e[type]=Array.isArray(e[type]) ? e[type].filter(n=>n&&typeof n==='object').slice(0,5000).map(n=>({...n,id:id(type),subjectId:rowMap.get(n.subjectId)||''})).filter(n=>n.subjectId):[];
    e.habits=Array.isArray(e.habits)?e.habits.slice(0,100).filter(x=>x && typeof x.name==='string'):[];
    e.habitChecks=e.habitChecks&&typeof e.habitChecks==='object'&&!Array.isArray(e.habitChecks)?e.habitChecks:{};
    e.goal=Math.max(.25,Math.min(16,Number(e.goal)||2));e.timer=null;e.notifDay='';
    pro.users[uid]=e;persist();BR.save();BR.refresh();renderAll();notice('Your backup was restored.');
  }
  function restoreAdmin(saved){
    if(current()?.role!=='admin')throw Error('Sign in as admin first.');
    const base=saved?.base,extra=saved?.extras;
    if(saved?.kind!=='studyplanner-admin-backup-v2'||!base||!Array.isArray(base.users)||!validRecordSet(base)||!extra||extra.version!==2||!extra.users||!Array.isArray(extra.announcements))throw Error('Not a compatible full backup.');
    if(!base.users.some(u=>u.id===userId() && u.role==='admin' && u.status==='Active'))throw Error('Backup does not include your current active admin account.');
    if(!confirm('Replace ALL local student and admin demo data with this backup? Current changes will be overwritten.'))return;
    pro=extra;persist();BR.replaceData(base);renderAll();notice('Full browser backup restored.');
  }
  async function importBackup(input,kind){
    const file=input.files?.[0];input.value='';if(!file)return;
    if(file.size>4*1024*1024){notice('Backup exceeds the 4 MB upload limit.');return;}
    try{
      const parsed=JSON.parse(await file.text());
      if(kind==='student')restoreStudent(parsed);else restoreAdmin(parsed);
    }catch(err){notice('Could not restore backup: '+err.message);}
  }
  function printReport(kind){
    const d=getData(),currentUser=current();if(!d||!currentUser)return;
    const print=document.createElement('section');print.id='pro-print-sheet';print.className='pro-print-sheet';
    const heading=`<div class="print-topline"><strong>▣ STUDY PLANNER PRO</strong><span>Generated ${H(labelDate(today()))}</span></div>`;
    if(kind==='student'){
      const logs=studentSessions(),tasks=studentTasks(),studied=hours(logs);
      const body=`<h1>Personal Study Progress Report</h1><p>Student: <strong>${H(currentUser.name)}</strong> · ${H(currentUser.course)}</p><div class="print-stats"><div><strong>${num(studied)} h</strong><small>Total study time</small></div><div><strong>${tasks.filter(t=>t.status==='Completed').length}/${tasks.length}</strong><small>Tasks completed</small></div><div><strong>${streak()} days</strong><small>Current study streak</small></div><div><strong>${num(userState().goal)} h</strong><small>Daily goal</small></div></div><h2>Subject hours</h2><table><tr><th>Subject</th><th>Logged hours</th><th>Target hours</th></tr>${studentSubs().map(s=>`<tr><td>${H(s.name)}</td><td>${num(hours(logs.filter(l=>l.subjectId===s.id)))}</td><td>${num(s.target)}</td></tr>`).join('')}</table><h2>Upcoming / Open Tasks</h2><table><tr><th>Task</th><th>Due</th><th>Priority</th><th>Status</th></tr>${tasks.filter(t=>t.status!=='Completed').sort((a,b)=>a.due.localeCompare(b.due)).map(t=>`<tr><td>${H(t.title)}</td><td>${H(labelDate(t.due))}</td><td>${H(t.priority)}</td><td>${H(t.status)}</td></tr>`).join('')}</table><p class="print-footer">Study Planner Pro · Personal browser-stored data · Academic demo</p>`;
      print.innerHTML=heading+body;
    }else{
      const rows=d.users.filter(u=>u.role==='student').map(u=>({...u,...performance(u.id)}));
      print.innerHTML=heading+`<h1>Class Performance Report</h1><p>Administration overview · ${rows.length} registered students</p><div class="print-stats"><div><strong>${rows.length}</strong><small>Total students</small></div><div><strong>${num(hours(d.sessions))} h</strong><small>Total logged time</small></div><div><strong>${d.tasks.filter(t=>t.status==='Completed').length}</strong><small>Completed tasks</small></div><div><strong>${d.subjects.length}</strong><small>Subjects</small></div></div><h2>Student Performance</h2><table><tr><th>Student</th><th>Hours</th><th>Completed</th><th>Rate</th><th>Streak</th></tr>${rows.map(r=>`<tr><td>${H(r.name)}</td><td>${num(r.studyHours)}</td><td>${r.done}/${r.tasks}</td><td>${r.completion}%</td><td>${r.streak}d</td></tr>`).join('')}</table><p class="print-footer">Study Planner Pro · Local demonstration data · Not a server-generated academic record</p>`;
    }
    $('#pro-print-sheet')?.remove();document.body.append(print);
    window.print();
    // Keep the print sheet available briefly for print preview; remove on return.
    window.addEventListener('afterprint',()=>print.remove(),{once:true});
  }
  function handleSubmit(ev){
    const form=ev.target,idName=form.id;
    if(!['goal-form','timetable-form','exam-form','note-form','habit-form','announcement-form'].includes(idName))return;
    ev.preventDefault();
    if(idName==='announcement-form'){
      if(current()?.role!=='admin')return;
      const title=$('#announcement-title').value.trim(),body=$('#announcement-body').value.trim();
      if(!title||!body)return;
      const existing=pro.announcements.find(a=>a.id===$('#announcement-id')?.value);
      if(existing)Object.assign(existing,{title,body,updatedAt:new Date().toISOString()});else pro.announcements.unshift({id:id('ann'),title,body,date:today(),createdAt:new Date().toISOString()});
      form.reset();$('#announcement-id').value='';persist();renderAll();notice(existing?'Announcement updated.':'Announcement published to student dashboards.');return;
    }
    if(current()?.role!=='student')return;
    const u=userState();
    if(idName==='goal-form'){
      const goal=Number($('#goal-target').value);if(!(goal>=.25&&goal<=16)){notice('Choose a daily target from 0.25 to 16 hours.');return;}
      u.goal=goal;persist();renderAll();notice('Daily study goal updated.');
    }else if(idName==='timetable-form'){
      const title=$('#timetable-title').value.trim(),subjectId=$('#timetable-subject').value,day=Number($('#timetable-day').value),start=$('#timetable-start').value,end=$('#timetable-end').value;
      if(!title||!studentSubs().some(s=>s.id===subjectId)||!start||!end||end<=start){notice('Enter a valid subject, time range and title.');return;}
      const existing=u.timetable.find(t=>t.id===$('#timetable-id')?.value);
      if(existing)Object.assign(existing,{title,subjectId,day,start,end});else u.timetable.push({id:id('tt'),title,subjectId,day,start,end});
      form.reset();$('#timetable-id').value='';setText('timetable-submit-text','+ Add weekly slot');persist();renderAll();notice(existing?'Weekly session updated.':'Weekly session added.');
    }else if(idName==='exam-form'){
      const title=$('#exam-title').value.trim(),subjectId=$('#exam-subject').value,date=$('#exam-date').value;
      if(!title||!studentSubs().some(s=>s.id===subjectId)||!date){notice('Add an exam title, subject and date.');return;}
      const existing=u.exams.find(e=>e.id===$('#exam-id')?.value);
      if(existing)Object.assign(existing,{title,subjectId,date});else u.exams.push({id:id('exam'),title,subjectId,date});
      form.reset();$('#exam-id').value='';$('#exam-date').value=date;setText('exam-submit-text','+ Add exam');persist();renderAll();notice(existing?'Exam updated.':'Exam saved to your countdown and calendar.');
    }else if(idName==='note-form'){
      const title=$('#note-title').value.trim(),body=$('#note-body').value.trim(),subjectId=$('#note-subject').value,noteId=$('#note-id').value;
      if(!title||!body||!studentSubs().some(s=>s.id===subjectId)){notice('Choose a subject and complete the note.');return;}
      const old=u.notes.find(x=>x.id===noteId);
      if(old)Object.assign(old,{title,body,subjectId,updatedAt:today()});
      else u.notes.push({id:id('note'),title,body,subjectId,updatedAt:today()});
      persist();clearNoteForm();renderAll();notice(old?'Note updated.':'Note saved.');
    }else if(idName==='habit-form'){
      const name=$('#habit-name').value.trim();if(!name)return;
      u.habits.push({id:id('habit'),name});form.reset();persist();renderAll();notice('New habit created.');
    }
  }
  function handleProClick(ev){
    const themeButton=ev.target.closest('.pro-theme-toggle');if(themeButton){themeToggle();return;}
    if(ev.target.closest('#notification-enable')){enableNotifications();return;}
    if(ev.target.closest('#focus-start')){startFocus();return;}
    if(ev.target.closest('#focus-pause')){pauseFocus();return;}
    if(ev.target.closest('#focus-reset')){resetFocus();return;}
    const modeButton=ev.target.closest('[data-focus-mode]');if(modeButton){const m=Number(modeButton.dataset.focusMode);chooseFocus(m===25?'focus':m===5?'break5':'break15');return;}
    if(ev.target.closest('#event-today')){$('#event-date').value=today();renderEvents();return;}
    if(ev.target.closest('#note-clear')){clearNoteForm();return;}
    if(ev.target.closest('#student-backup')){studentBackup();return;}
    if(ev.target.closest('#admin-backup')){adminBackup();return;}
    if(ev.target.closest('#student-print')){printReport('student');return;}
    if(ev.target.closest('#admin-print')){printReport('admin');return;}
    const b=ev.target.closest('[data-pro-action]');if(!b)return;
    const act=b.dataset.proAction,recId=b.dataset.id,u=userState();
    if(act==='task-jump'){
      // opens the existing Bootstrap edit modal on the Tasks page after navigation
      sessionStorage.setItem('studyplanner_open_task',recId);location.assign('tasks.html');return;
    }
    if(!u && !['delete-announcement'].includes(act))return;
    if(act==='edit-announcement'){
      if(current()?.role!=='admin')return;
      const a=pro.announcements.find(x=>x.id===recId);if(!a)return;
      $('#announcement-id').value=a.id;$('#announcement-title').value=a.title;$('#announcement-body').value=a.body;
      $('#announcement-form').scrollIntoView({block:'center',behavior:'smooth'});$('#announcement-title').focus();return;
    }
    if(act==='edit-timetable'){
      const rec=u.timetable.find(x=>x.id===recId);if(!rec)return;
      $('#timetable-id').value=rec.id;$('#timetable-title').value=rec.title;$('#timetable-subject').value=rec.subjectId;
      $('#timetable-day').value=String(rec.day);$('#timetable-start').value=rec.start;$('#timetable-end').value=rec.end;
      setText('timetable-submit-text','Save changes');$('#timetable-form').scrollIntoView({block:'center',behavior:'smooth'});$('#timetable-title').focus();return;
    }
    if(act==='edit-exam'){
      const rec=u.exams.find(x=>x.id===recId);if(!rec)return;
      $('#exam-id').value=rec.id;$('#exam-title').value=rec.title;$('#exam-subject').value=rec.subjectId;$('#exam-date').value=rec.date;
      setText('exam-submit-text','Save changes');$('#exam-form').scrollIntoView({block:'center',behavior:'smooth'});$('#exam-title').focus();return;
    }
    if(act==='delete-announcement'){
      if(current()?.role!=='admin')return;
      pro.announcements=pro.announcements.filter(a=>a.id!==recId);
    }else if(act==='delete-exam')u.exams=u.exams.filter(e=>e.id!==recId);
    else if(act==='delete-timetable')u.timetable=u.timetable.filter(t=>t.id!==recId);
    else if(act==='delete-note'){
      if(!confirm('Delete this note permanently?'))return;
      u.notes=u.notes.filter(n=>n.id!==recId);
    }else if(act==='edit-note'){
      const n=u.notes.find(n=>n.id===recId);if(!n)return;
      $('#note-id').value=n.id;$('#note-title').value=n.title;$('#note-body').value=n.body;$('#note-subject').value=n.subjectId;
      setText('note-submit','Update note');$('#notes-center').scrollIntoView({behavior:'smooth'});$('#note-title').focus();return;
    }else if(act==='delete-habit'){
      if(!confirm('Remove this habit and its check-ins?'))return;
      u.habits=u.habits.filter(h=>h.id!==recId);delete u.habitChecks[recId];
    }else if(act==='toggle-habit'){
      const day=b.dataset.day;
      if(!u.habits.some(h=>h.id===recId)||!/^\d{4}-\d{2}-\d{2}$/.test(day))return;
      const arr=u.habitChecks[recId]||[];
      u.habitChecks[recId]=arr.includes(day)?arr.filter(x=>x!==day):[...arr,day];
    }else return;
    persist();renderAll();
  }
  function handleChanges(ev){
    if(ev.target.matches('[data-pro-status-id]'))setTaskStatus(ev.target.dataset.proStatusId,ev.target.value);
    if(ev.target.matches('#focus-subject')){const t=getTimer();if(t&&!t.running){t.subjectId=ev.target.value;persist();}}
    if(ev.target.matches('#event-date'))renderEvents();
  }
  function registerDragAndDrop(){
    document.addEventListener('dragstart',ev=>{
      const card=ev.target.closest('.kanban-card');if(!card)return;
      ev.dataTransfer.effectAllowed='move';ev.dataTransfer.setData('text/plain',card.dataset.taskId);card.classList.add('dragging');
    });
    document.addEventListener('dragend',()=>{$$('.kanban-card.dragging').forEach(c=>c.classList.remove('dragging'));$$('.kanban-column').forEach(c=>c.classList.remove('drop-active'));});
    document.addEventListener('dragover',ev=>{const col=ev.target.closest('[data-drop-status]');if(!col)return;ev.preventDefault();ev.dataTransfer.dropEffect='move';col.classList.add('drop-active');});
    document.addEventListener('dragleave',ev=>{const col=ev.target.closest('[data-drop-status]');if(col&&!col.contains(ev.relatedTarget))col.classList.remove('drop-active');});
    document.addEventListener('drop',ev=>{const col=ev.target.closest('[data-drop-status]');if(!col)return;ev.preventDefault();$$('.kanban-column').forEach(c=>c.classList.remove('drop-active'));setTaskStatus(ev.dataTransfer.getData('text/plain'),col.dataset.dropStatus);});
  }
  function init(){
    themeApply();
    document.addEventListener('click',handleProClick);
    document.addEventListener('submit',handleSubmit);
    document.addEventListener('change',handleChanges);
    $('#note-search')?.addEventListener('input',renderNotes);
    $('#performance-sort')?.addEventListener('change',renderPerformance);
    $('#student-restore')?.addEventListener('change',ev=>importBackup(ev.target,'student'));
    $('#admin-restore')?.addEventListener('change',ev=>importBackup(ev.target,'admin'));
    document.addEventListener('click',ev=>{const b=ev.target.closest('[data-cal-date]');if(b && $('#event-date')){$('#event-date').value=b.dataset.calDate;renderEvents();}});
    registerDragAndDrop();
    if(!current())return;
    if($('#exam-date'))$('#exam-date').value=moveDate(today(),5);
    if($('#event-date'))$('#event-date').value=today();
    const pendingTask=sessionStorage.getItem('studyplanner_open_task');
    if(pendingTask && $('#kanban-board')){
      sessionStorage.removeItem('studyplanner_open_task');
      setTimeout(()=>{if(studentTasks().some(t=>t.id===pendingTask))BR.openTask(pendingTask);},80);
    }
    renderAll();
    if($('#focus-ring')){
      tickFocus();focusInterval=setInterval(tickFocus,500);
      document.addEventListener('visibilitychange',()=>{if(!document.hidden)tickFocus();});
    }
    window.addEventListener('studyplanner:changed',renderAll);
    window.addEventListener('studyplanner:record-deleted',event=>{
      const {type,id}=event.detail||{};
      if(type==='subject')for(const account of Object.values(pro.users)){
        for(const key of ['notes','timetable','exams'])if(Array.isArray(account[key]))account[key]=account[key].filter(x=>x.subjectId!==id);
        if(account.timer?.subjectId===id){account.timer.running=false;account.timer.endAt=null;account.timer.subjectId='';}
      }
      if(type==='student')delete pro.users[id];
      if(['subject','student'].includes(type)){persist();renderAll();}
    });
    remindDue();setInterval(remindDue,60*1000);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
