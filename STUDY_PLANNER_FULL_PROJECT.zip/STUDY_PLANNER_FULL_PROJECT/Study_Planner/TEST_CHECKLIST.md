# Study Planner Pro — Functional testing checklist

## Browser setup

- [ ] Extract the full ZIP, including `assets/`.
- [ ] Open `index.html` with VS Code Live Server, not inside ZIP.
- [ ] Demo Student login: `student@studyplanner.com` / `Student@123`.
- [ ] Demo Admin login: `admin@studyplanner.com` / `Admin@123`.

## Student flows

- [ ] Dashboard: set daily goal, then switch Dark/Light theme and navigate to another page.
- [ ] Dashboard: start/pause/reset Pomodoro and select a subject. A completed focus session records actual hours.
- [ ] Study Plan: create/edit/delete a study session. Add/edit/delete repeating timetable slot and exam.
- [ ] Subjects: create/edit/delete subjects and create/edit/delete/search notes.
- [ ] Tasks: create/edit/delete tasks; filter and update priority; move status using Kanban dropdown or drag-and-drop.
- [ ] Progress: add/edit/delete study-hour log (History), check progress; track habits and badges.
- [ ] Progress: export JSON backup, restore trusted JSON, print report.

## Admin flows

- [ ] Admin Dashboard: create/edit/delete an announcement; student sees it on same browser profile.
- [ ] Manage Students: add/edit/disable/remove demo student; inspect performance rows.
- [ ] Manage Subjects / Plans: create/edit/delete data and confirm list updates.
- [ ] Reports: view analytics, export CSV/JSON, import trusted JSON and print class report.

## Important limitations

Front-end demo only: passwords are stored in browser storage, not securely. No real email password resets, cloud sync, or true cross-device admin management. Browser Notifications require a secure context and a user grant; the site must be open. No external AI model is used.
