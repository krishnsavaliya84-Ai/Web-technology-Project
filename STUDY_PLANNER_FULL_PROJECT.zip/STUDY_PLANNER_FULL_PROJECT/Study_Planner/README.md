# StudyPlanner Pro — Client & Admin files in separate folders

This is the same **13-page StudyPlanner Pro project**, reorganized to match your reference screenshot. The student and administrator code are separated. **The existing five login validations and functionality are retained.**

## How to run

1. Extract this ZIP; **do not move individual HTML files away from their folder**.
2. Open this entire extracted folder in VS Code.
3. Use **Live Server** on **`Client/index.html`** to start Student Login, or **`Admin/admin-login.html`** for Admin Login.
4. To keep sessions and shared data working between Admin and Client, use the **same Live Server origin and browser profile** (do not open Admin and Client in separate servers/ports).

**Student demo:** `student@studyplanner.com` / `Student@123`  
**Admin demo:** `admin@studyplanner.com` / `Admin@123`

## Folder structure

```text
StudyPlanner_Pro_Admin_Client_Separate/
├── Admin/                ← 6 administrator HTML pages
│   ├── admin-login.html
│   ├── admin-dashboard.html
│   ├── manage-students.html
│   ├── manage-subjects.html
│   ├── manage-plans.html
│   ├── reports.html
│   └── assets/           ← Admin's CSS, JS, Bootstrap files
├── Client/               ← 7 student HTML pages
│   ├── index.html        ← Student Login / START HERE
│   ├── register.html
│   ├── dashboard.html
│   ├── study-plan.html
│   ├── subjects.html
│   ├── tasks.html
│   ├── progress.html
│   └── assets/           ← Client's CSS, JS, Bootstrap files
├── previews/             ← original UI previews
├── validation-screenshots/ ← five assignment validation screenshots
├── README.md
└── other original project documentation (*.md)
```

Each folder has its own `assets` copy to keep that side's files together, as requested. The original files still share user data through browser `localStorage` because both are served from the same Live Server origin. This is a **front-end-only educational demo**, not secure authentication.

---

## Original project details

# Study Planner Pro — 13 Connected Pages (Separate Validated Logins)

A complete, responsive **Web Technology college project** based on the supplied 13-screen wireframe. The Student and Admin Login are now **two dedicated, individually validated HTML pages**, matching the original separate wireframe screens. To preserve all 12 existing screens and add an admin login rather than deleting a feature page, the deliverable now contains **13 linked HTML pages**.

## Technology stack

- **HTML5** for page content, forms, navigation, tables, and accessibility.
- **CSS3** for layouts, professional styling, dark/light themes, responsiveness, and custom progress charts.
- **Bootstrap 5 (bundled locally)** for the grid, components, navigation, form styles, and modals.
- **Vanilla JavaScript** for interactive behavior, persistence, calculations, drag-and-drop, and reports.

**Tailwind CSS is intentionally not loaded.** It was optional, and using the existing Bootstrap grid with custom CSS keeps this project balanced, easy to understand, and fully usable **offline**. No React, Vue, jQuery, database, server-side framework, or external chart library is used.

## Quick start

1. Extract the entire ZIP, without moving files out of their folders.
2. Open the extracted project folder in **VS Code**.
3. Run `Client/index.html` using **Live Server** (recommended), or serve the folder using any simple local static web server.
4. Start with `Client/index.html` for **Student Login**, or select **Admin Login** to open `Admin/admin-login.html`.

**Student demo:** `student@studyplanner.com` / `Student@123`  
**Admin demo:** `admin@studyplanner.com` / `Admin@123`

You can also register new student accounts. The sample student has demonstration subjects, tasks, study hours, an exam, notes and habits, so the dashboard is populated immediately.

> Important: This is a **front-end-only prototype**. Login credentials and data are held in `localStorage`, not securely managed on a server. Never use your real email passwords or sensitive information. Students and admins only share data within the **same browser profile and site origin**. Separate devices are not synchronized.

## The 13 connected web pages

| # | File | Main screen |
|---|---|---|
| 1 | `Client/index.html` | Student Login (with inline validation) |
| 2 | `Admin/admin-login.html` | Admin Login (with role checks) |
| 3 | `Client/register.html` | Student Registration (strong-password and duplicate-email validation) |
| 4 | `Client/dashboard.html` | Student Dashboard, Daily Goals, Pomodoro Timer, Streak, Exam Countdown |
| 5 | `Client/study-plan.html` | My Study Plan, Calendar, Weekly Timetable, Exams |
| 6 | `Client/subjects.html` | Subjects and searchable Notes Manager |
| 7 | `Client/tasks.html` | Tasks & Assignments, Priority Management, Kanban Board |
| 8 | `Client/progress.html` | Progress & Analytics, Habits, Badges, Study Hour History |
| 9 | `Admin/admin-dashboard.html` | Admin Dashboard, Announcements, Performance Leaderboard |
| 10 | `Admin/manage-students.html` | Admin Student Management & Performance |
| 11 | `Admin/manage-subjects.html` | Admin Subject Management |
| 12 | `Admin/manage-plans.html` | Admin Study Plans, Tasks & Deadline Watch |
| 13 | `Admin/reports.html` | Admin Reports, Backup / Restore and Print |

All pages retain their existing navigation including links between Client and Admin folders, and login/logout now routes to the correct student or admin portal. Common CSS/JS is shared. The new `assets/css/auth-enhanced.css` and `assets/js/auth-validation.js` are loaded only by login/registration pages.

### Login and registration validation

- Student Login and Admin Login are separate pages and verify the expected **account role**.
- Required email and password, password length (8–64), password complexity (uppercase, lowercase, digit, symbol, no spaces), email format, and an optional 10-digit Indian mobile-number pattern check with inline messages. The phone field is for assignment demonstration only: it is not saved or used to authenticate. Correct login credentials and active account state are still checked.
- Password show/hide, demo-credentials autofill, Remember Me toggle: checked stores session in `localStorage`, unchecked in `sessionStorage`.
- An in-browser demonstration retry delay starts after five wrong attempts per account/portal for 30 seconds. This is not server-side security.
- Registration checks full name, unique email, strong password (8–64 characters, uppercase, lowercase, number, symbol, no spaces), confirmation, course/branch, semester 1–8, and consent.
- A successful registration creates a student role only, never an admin role.
- Direct page entry into a screen with the wrong local demo role redirects to the corresponding dashboard; signed-out users are routed to the matching login portal.
- Forgot-password email and secure authorization **are not available** without a backend. Never use a real password in this demonstration.

See `VALIDATION_GUIDE.md` for all test cases, security limitations, and how to demonstrate the project.

## 19 requested advanced features

1. **Pomodoro Timer:** 25-minute focus, 5/15-minute breaks, start/pause/reset, persisted countdown, automatic logging of completed focus time to the selected subject.
2. **Daily Study Goals:** editable daily hours target, progress bar calculated from real logged hours.
3. **Dark / Light Mode:** one-click switch, remembered across pages and sessions.
4. **Exam Countdown:** exam add/edit/delete, days remaining, next-exam dashboard tile.
5. **Weekly Timetable:** repeatable Monday–Sunday subject/time slots with add/edit/delete.
6. **Task Priorities:** High/Medium/Low, automatic overdue/due-today coloring and filters.
7. **Study Streak:** consecutive days with logged study sessions, shown on Dashboard and Progress.
8. **Smart Task Suggestions:** local priority/deadline rules select what to do next, without external AI APIs.
9. **Kanban Task Board:** drag cards between To Do, In Progress, and Completed; also has an accessible status selector.
10. **Notes Manager:** subject-wise notes, search, add, edit and delete.
11. **Habit Tracker:** add habits, seven-day check-in grid, toggle completed dates, delete habits.
12. **Achievement Badges:** nine milestones calculated from logged hours, completed tasks, streaks, notes, subject count, focus sessions, and goals.
13. **Browser Notifications:** user-triggered permission request, due-task/exam reminder when the app is open, plus Pomodoro completion alerts.
14. **Advanced Analytics:** 14-day bar charts, weekly comparisons, most productive day, goal completion and subject-hour comparisons.
15. **Calendar Event View:** unified task deadlines, study plan events, exam dates and repeating timetable items for any selected day.
16. **Admin Student Performance:** sortable class performance table, completion %, logged study hours, streak, last activity, dashboard leaderboard.
17. **Admin Announcements:** publish/delete announcements; students see the same-browser admin notices.
18. **Backup & Restore:** download/import JSON backups. Student backups include personal data **without passwords**; admin backups include all locally stored demo data **including credentials**.
19. **Printable Reports:** personal progress report or aggregated admin class report via browser Print / Save as PDF.

Refer to [FEATURE_MATRIX.md](FEATURE_MATRIX.md) for a feature-to-page reference and suggested demo flow.

## Where information is saved

| Storage | Key | What it holds |
|---|---|---|
| localStorage | `studyplanner_data_v1` | Demo accounts, subjects, tasks, study plans, actual study logs |
| localStorage | `studyplanner_pro_v2` | Daily goals, timers, exams, timetable, notes, habits, announcements |
| localStorage | `studyplanner_theme_v2` | Light or dark theme |
| localStorage | `studyplanner_session_v1` | LocalStorage if Remember Me is checked, otherwise SessionStorage |

**Backup precautions:** Import overwrites the relevant existing local records after asking for confirmation. Export a backup before importing someone else's JSON. JSON files should come from a trusted source.

## Browser notification limitations

Browser notifications only work where the Notifications API is supported and the page runs in a **secure context**, such as `http://localhost` via Live Server or HTTPS. The user must grant permission. Reminder checks happen **while a page from this website remains open**; this project cannot send mobile push messages or keep running after the browser is fully closed without a service worker/server (intentionally outside this project's scope). In-app deadlines and highlights always remain visible.

## Academic / technical limitations

- Real authentication, password reset email, Google OAuth, multi-device sync, and secure student permissions require a backend and were deliberately not simulated as live services.
- The Admin account is a demo UI role, not a real secure administrator on the public internet.
- All analytics are computed from the browser's local study logs and tasks.
- Smart suggestions use transparent JavaScript rules, **not** a machine learning model.
- The timer calculates elapsed time from stored timestamps and records an expired session when the page is next opened; it does not continue executing JavaScript after the browser is closed.
- Browser **Print** can export a PDF using the system print dialog; no PDF library or extra language is used.

## Folder structure

```text
StudyPlanner_Pro_Validated_13_Pages/
├── index.html
├── admin-login.html
├── register.html
├── dashboard.html
├── study-plan.html
├── subjects.html
├── tasks.html
├── progress.html
├── admin-dashboard.html
├── manage-students.html
├── manage-subjects.html
├── manage-plans.html
├── reports.html
├── README.md
├── FEATURE_MATRIX.md
├── previews/
│   ├── desktop-dashboard.png
│   └── mobile-dashboard.png
└── assets/
    ├── css/
    │   ├── style.css
    │   ├── pro.css
    │   └── auth-enhanced.css
    ├── js/
    │   ├── app.js
    │   ├── pro.js
    │   └── auth-validation.js
    └── vendor/
        ├── bootstrap.min.css
        └── bootstrap.bundle.min.js
```

## Verification

The project was checked for JavaScript syntax, the expected 13 pages, static relative asset links, desktop/mobile overflow, live dashboard goal updates, Pomodoro controls and completion logs, task status changes, exam/timetable updates, notes and habits, printable reports, both JSON backup/restore flows, and cross-view admin announcements. A scripted browser DOM test found no runtime errors in the exercised interactions. Because this environment blocked direct local browser URL navigation, **run a final full page-to-page smoke test in VS Code Live Server** before college submission.

## Repair update — November 2026

- Fixed missing **edit** actions for weekly timetable entries, exams and admin announcements.
- Added **Study Hour History** to Progress, allowing correction/deletion of manual or timer study logs; dashboard and analytics update instantly.
- Subject and student deletions now clean up related notes, exams, timetable slots and student-specific Pro data.
- Study-hour edit forms now update existing records rather than creating duplicates.
- Added `TEST_CHECKLIST.md` with verifiable tests and limitations.

If the interface seems blank or CSS is missing, extract the ZIP **fully** before opening the project. Do not open `index.html` from inside the compressed ZIP viewer. For local notifications, open through VS Code Live Server.

## Auth upgrade — November 7, 2026

- Split the previously shared Student/Admin Login into separate matching pages.
- Added complete browser-side login and registration validation with accessible inline errors.
- Introduced Remember Me persistence and separate Admin logout destination.
- Verified 21 isolated Chromium checks (validation, successful login/registration storage, cross-role credential rejection, responsive overflow). Direct localhost URL navigation was blocked by the test environment, so a **live end-to-end URL/navigation smoke test is still required** in VS Code.
- The project now contains **13 HTML pages**; no previously existing feature page was removed.
